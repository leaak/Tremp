﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Linq;

namespace finalTrempProgect.Models
{
    public class User
    {

        private static XDocument x;
        #region parameters
        public String Email { get; set; }
        public String Password { get; set; }
        public String Sms { get; set; }
        public string Name { get; set; }

        #endregion
        #region Constractors
        public User()
        {
        }
        public User(string path, string password, string email, string sms, string name, bool b)
        {
            this.Name = name;
            this.Password = password;
            this.Email = email;
            this.Sms = sms;

        }
        public User(string path, string password, string email, string sms, string name)
        {
            x = XDocument.Load(path);
            this.Name = name;
            this.Password = password;
            this.Email = email;
            this.Sms = sms;
            XElement user1 = new XElement("user");
            user1.Add(new XAttribute("name", this.Name));
            user1.Add(new XAttribute("password", this.Password));
            user1.Add(new XAttribute("email", this.Email));
            user1.Add(new XAttribute("sms", this.Sms));
            x.Element("users").Add(user1);
            x.Save(path);

        }
        #endregion
        #region Functions
        public static bool isExsistingPassword(string pass, string path)
        {
            x = XDocument.Load(path);
            XElement xel = x.Descendants("user").FirstOrDefault(w => w.Attribute("password").Value == pass);
            return xel != null;

        }
        public User getUser(string pass, string path)
        {
            x = XDocument.Load(path);
            XElement xel = x.Descendants("user").FirstOrDefault(w => w.Attribute("password").Value == pass);
            if (xel != null)
                return new User(path, xel.Attribute("password").Value.ToString(), xel.Attribute("email").Value.ToString(), xel.Attribute("sms").Value.ToString(), xel.Attribute("name").Value.ToString(), false);
            else
                return null;
        }
        #endregion
    }
}