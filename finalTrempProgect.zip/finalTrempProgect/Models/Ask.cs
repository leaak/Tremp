﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace finalTrempProgect.Models
{
    public class Ask
    {
            #region parameters
            //========Details===========
            public string Password { get; set; }
            public DateTime TravelTime { get; set; }
            public String Source { get; set; }
            public String Destinition { get; set; }
            public int NumSeats { get; set; }
            #endregion
            #region ctor
            public void Asker(string password, DateTime Time, String Source, String Destinition, int NumSeats, bool IsWomen, bool Ismen, List<string> contacts)
            {
                this.Password = password;
                this.TravelTime = Time;
                this.Source = Source;
                this.Destinition = Destinition;
                this.NumSeats = NumSeats;
                //if (contacts != null)
                //this.Contacts = new List<string>(contacts);
            }

            #endregion
    }
}