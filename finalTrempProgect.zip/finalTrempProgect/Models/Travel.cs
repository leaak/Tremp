﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace finalTrempProgect.Models
{
    public class Travel
    {
        public string from { get; set; }
        public string to { get; set; }
        public string when { get; set; }
        public bool isSuggest { get; set; }
        public Travel(string from, string to, string d, bool IsSuggest)
        {
            this.from = from;
            this.to = to;
            this.when = d;
            this.isSuggest = IsSuggest;

        }
        //בונה לקבועים התאריך ישלח עפי יום ביקוש האישור
        //והזמן עפי המבקש
        //public Travel(Suggest s, Ask A,DateTime D)
        //{
        //    this.S = s;
        //    this.A = A;
        //    this.TimeOfTraveling = new DateTime(D.Year, D.Month, D.Day, S.TravelTime.Hour,S.TravelTime.Minute, S.TravelTime.Second);


        //} 


    }
}