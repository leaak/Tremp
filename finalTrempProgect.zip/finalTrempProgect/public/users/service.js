﻿/// <reference path="controller.js" />
function UsersService($http, $location) {
    var globalUser;
    var path;
    var isSuit = null;
    var i = 0;
    var directionsService;
    var searchresult;
    var messageResponse;
    var messageResponse2;
    var myData;
    var suggestForShow = [];
    var myDataMessage = "";
    var init = function (directionsService, fromSugg, toSugg, i, askPointFrom, askPointTo, item) {
        directionsService.route({
            origin: fromSugg,
            destination: toSugg,
            travelMode: google.maps.TravelMode.DRIVING
        },
            function (response, status) {
                console.log("response!!  " + response.value);
                console.log("@@i@@ " + i);
                var fromIndex = -1;
                var toIndex = -1;
                if (i == 0 && suggestForShow.length > 0)
                    while (suggestForShow.length > 0)
                        suggestForShow.pop();
                for (var j = 0; j < response.routes[0].overview_path.length; j++)
                {
                    var point = response.routes[0].overview_path[j];
                    var destanceFrom = (google.maps.geometry.spherical.computeDistanceBetween(point, askPointFrom) / 1000).toFixed(2);
                    var destanceTo = (google.maps.geometry.spherical.computeDistanceBetween(point, askPointTo) / 1000).toFixed(2);
                    var geocoder = new google.maps.Geocoder();
                    if (destanceFrom <= 10) 
                        fromIndex = j;
                    if (destanceTo <= 10) 
                        toIndex = j;
                }
                console.log("I  :  "+i+"  toIndex  " + toIndex + "   " + "fromIndex  " + fromIndex)
                if (fromIndex != -1 && toIndex != -1 && fromIndex < toIndex) {
                    console.log("Suit sug  i + item" + i + " ,  " + item);
                    suggestForShow.push(item);
                }
                else
                    console.log("NOT   i" + i);
                console.log("suggestForShow in init  " + suggestForShow.length);
            }
        );
    }
    return {
        test: function (fn, callback1) { setTimeout(function () { fn(), callback1() }, 6000);},
        getmessageResponse: function () { return messageResponse; },
        getmessageResponse2: function () { return messageResponse2; },
        setmessageResponse: function (x) {  messageResponse=x; },
        setmessageResponse2: function (x) { messageResponse2 = x; },
        getmessageResponseIndex: function (i) { str = messageResponse.split('#'); return str[i];},
        getsearchresult: function () { return searchresult; },
        getmyDataMessage: function () { return myDataMessage;},
        getMyData: function () {    return myData },
        getSuggestForShow: function () { return suggestForShow; },
        setSuggestForShow: function (x) { suggestForShow = x; },
        gu: function () { return globalUser; },
        setpath: function (p) { path = p; },
        mydata: function () {
            return $http({
                url: '/My/getData',
                type: "json",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                data: { user: globalUser },
            }).success(function (data) {
                console.log("data1 " + data);
                myData = [];
                while (myData!=undefined&& myData.length > 0)
                        myData.pop();
                for (var i = 0; i < data.length; i++) {
                    myData.push(JSON.parse(data[i]));
                    console.log("myData " + myData);
                }
                
                console.log("myData   " + myData);
            }).error(function (data) {
            });
        },
        login: function (user) {
            return $http({
                url: '/My/login',
                type: "json",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                data: { user: user },
            }).success(function (data) {
                    //alert("@@@@@@" + path);
                    globalUser = data.user;
                if(path!=undefined&&path!=""&&path!=null)
                    $location.path(path);
                else
                    $location.path('/login');
            }).error(function (data) {
            });
        },
        getUser: function () { return globalUser; },
        registering: function (password) {
            return $http({
                url: '/My/registering',
                type: "json",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                data: { password: password },
            }).success(function (data) {
                    //alert("@@@@@@" + path);
                    globalUser = data.user;
                    if(path!=undefined&&path!=""&&path!=null)
                        $location.path(path);
                else
                    $location.path('/login');
            }).error(function (data) {
                //alert("error");
            });
        },
        ask: function (askDetails, from, to) {
            askDetails.valuefrom = from;
            askDetails.valueto = to;
            askDetails.userPass = globalUser.Password;
            console.log(askDetails.from);
            return $http({
                url: '/My/askTravel',
                type: "json",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                data: { askDetails: askDetails },
            }).success(function (data) {
                console.log(data);
                console.log("le  " + data.suggestList.Data.length);
                directionsService = new google.maps.DirectionsService;
                var askPointFrom = new google.maps.LatLng(data.askfromLat, data.askfromLen);
                var askPointTo = new google.maps.LatLng(data.askToLat, data.askToLen);
                console.log("askPointFrom" + askPointFrom);
                console.log("askPointTo" + askPointTo);
                var item;
                for (i = 0; i < data.suggestList.Data.length; i++)
                {
                    item = JSON.parse(data.suggestList.Data[i]);
                    var fromSugg = new google.maps.LatLng(item.SourceLat, item.SourceLen);
                    var toSugg = new google.maps.LatLng(item.DestinitionLat, item.DestinitionLen);
                    init(directionsService, fromSugg, toSugg, i, askPointFrom, askPointTo, item);
                    console.log(" i " + i);
                    console.log("suggestForShow in loop " + suggestForShow.length);
                }
                console.log("suggestForShow  " + suggestForShow.length);
                for (var d = 0; d < suggestForShow.length; d++)
                    console.log("suggestForShow d " + d + " : " + suggestForShow[d].DestinitionName + "  ,  " + suggestForShow[d].SourceName + "  ,  " + suggestForShow[d].TravelTime + "  ,  " + suggestForShow[d].UserSuggest.Name);
            }).error(function (data) {
                //alert("error");
            })
        },
        give: function (suggest, from, to) {
            suggest.valuef = from;
            suggest.valuet = to;
            console.log("gu  " + globalUser);
            suggest.userPass = globalUser.Password;
            return $http({
                url: '/My/suggestTravel',
                type: "json",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                data: { suggest: suggest },
            }).success(function (data) {
                messageResponse = data.messageResponse;
                messageResponse2 = data.messageResponse2;
                    $location.path('/personal');
            }).error(function (data) {
                //alert("error");
            });
        },
        attach: function (selectTravel) {
            return $http({
                url: '/My/attach',
                type: "json",
                method: "POST",
                contentType: "application/json; charset=utf-8",
                data: { Travel: selectTravel, askUser: globalUser },
            }).success(function (data) {
                messageResponse = data.messageResponse;
                messageResponse2 = data.messageResponse2;
                console.log("suggestForShow.length  " + suggestForShow.length);
                    while (suggestForShow.length > 0)
                        suggestForShow.pop();
                   $location.path('/personal');
            }).error(function (data) {
                //alert("error");
            });
        }
    }
}
angular.module('main').factory('UsersService', UsersService);
UsersService.$inject = ['$http', '$location'];

