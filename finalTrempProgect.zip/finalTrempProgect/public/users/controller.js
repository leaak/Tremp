﻿console.log('ctrl')
function usersCtrl($location, $scope, UsersService) {
    this.showRegister = false
    this.user = UsersService.gu();
    this.messageResponse2 = UsersService.getmessageResponse2();
    this.searchResult;
    this.myDataMessage=UsersService.getmessageResponse();
    this.personalData=UsersService.getMyData();
    this.suggestForShow = UsersService.getSuggestForShow();
    this.isAsign = (this.user != null && this.user != "" && this.user != undefined) ? true : false;
    this.setmessages = function () {
        UsersService.setmessageResponse("");
        UsersService.setmessageResponse2("");
        this.messageResponse2 = UsersService.getmessageResponse2();
        this.myDataMessage = UsersService.getmessageResponse();
    };
    this.login = function () {
        //alert("cont  " + this.path);
        UsersService.setpath('/' + this.path);
        UsersService.login(this.user).then(function (response) {
            $scope.error1 = !response.data.success && response.data.message1;
            $scope.error2 = !response.data.success && response.data.message2;
            $scope.welcome = response.data.success;
            if (response.data.success) {
                console.log($('#myModal'));
                $('#myModal').modal('hide');
                $(".modal-backdrop").remove();
                $(".active").removeClass('active');
                $("#ask").addClass('active');
            }
        }, function (err) {
            this.error = err;
        });
      
    }
    this.registering = function () {
        //alert("cont" + this.path);
        UsersService.setpath('/' + this.path);
        console.log(this.user);
        UsersService.registering(this.password).then(function (response) {
            $scope.errorReg = !response.data.success && response.data.message;
            if (response.data.success) {
                $('#myModal').modal('hide');
                $(".modal-backdrop").remove();
                $(".active").removeClass('active');
                $("#ask").addClass('active');
            }
            console.log(response);
        }, function (err) {
            this.error = 'xxx' + err;
        });

    },
    this.ask = function () {
        setTimeout(2000);
        var from = $('#valueLocFrom').val();
        var to = $('#valueLocTo').val();
        UsersService.ask(this.askDetails, from, to).then(function (response) {
            UsersService.test(function () { alert("1 :  " + Date.now); }, function () {
                alert("2  :  "+Date.now);
                this.suggestForShow = UsersService.getSuggestForShow();
                console.log("Ctrl suggestForShow.length" + this.suggestForShow.length);
                console.log("UsersService.getSuggestForShow() :  " + UsersService.getSuggestForShow());
                if (this.suggestForShow.length > 0) {
                    $scope.aaa = suggestForShow.length;
                    $scope.aaa += " נסיעות מתאימות ";
                }
                else {
                    $scope.aaa = "  לא נמצאו ";
                    $scope.aaa += "נסיעות מתאימות";
                }
            });
            console.log("uc  suggestForShow  " + this.suggestForShow)
                if (response.data.success) {
                    console.log($('#myModal'));
                    $('#myModal').modal('hide');
                    $(".modal-backdrop").remove();
                    $(".active").removeClass('active');
                    $("#ask").addClass('active');
                   
                }
                $location.path('/ask');
            }, function (err) {
                this.error = err;
            });

    }
    this.attach = function (selectedTravel) {
        console.log("selectedTravel " + selectedTravel);
        UsersService.attach(selectedTravel).then(function (response) {
            this.suggestForShow = UsersService.getSuggestForShow();
            console.log($('#myModal'));
            $('#myModal').modal('hide');
            $(".modal-backdrop").remove();
            $(".active").removeClass('active');
            $("#logintab").addClass('active');
        }, function (err) {
            this.error = err;
        });
    }
        this.give = function () {
            var from = $('#valueLocFrom').val();
            var to = $('#valueLocTo').val();
            UsersService.give(this.suggest, from, to).then(function (response) {
                    console.log($('#myModal'));
                    $('#myModal').modal('hide');
                    $(".modal-backdrop").remove();
                    $(".active").removeClass('active');
                    $("#logintab").addClass('active');
            }, function (err) {
                this.error = err;
            });

        },
    this.mydata = function () {
        //alert("in mydata");
        UsersService.mydata().then(function (response) {
            console.log("2222");
            this.personalData = UsersService.getMyData();
            //Tovi
            $scope.personalData = this.personalData;
            console.log("personalData  uc" + personalData);
        }, function (err) {
            this.error = err;
        });

    }

}
angular.module('main').controller('usersCtrl', usersCtrl);
usersCtrl.$inject = ['$location', '$scope', 'UsersService'];
