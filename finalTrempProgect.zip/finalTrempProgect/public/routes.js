/// <reference path="users/views/AsdDetails.html" />
//Setting up route

function config($routeProvider) {
    //states for my app
    $routeProvider
        .when('/login', {
            templateUrl: 'public/users/views/login.html',
            controller: 'usersCtrl',
            controllerAs: 'uc'
        })
        .when('/ask', {
            templateUrl: 'public/users/views/AskDetails.html',
            controller: 'usersCtrl',
            controllerAs: 'uc'
        })
        .when('/suggest', {
            templateUrl: 'public/users/views/suggestDetails.html',
            controller: 'usersCtrl',
            controllerAs: 'uc'
        })
        .when('/signup', {
            templateUrl: 'public/users/views/signup.html',
            controller: 'usersCtrl',
            controllerAs: 'uc'
        })
        .when('/personal', {
            templateUrl: 'public/users/views/PersonalData.html',
            controller: 'usersCtrl',
            controllerAs: 'uc'
        })
    .otherwise({
        templateUrl: 'public/users/views/AskDetails.html',
        controller: 'usersCtrl',
        controllerAs: 'uc'
    });
}

angular.module('main').config(config);
config.$inject = ['$routeProvider'];