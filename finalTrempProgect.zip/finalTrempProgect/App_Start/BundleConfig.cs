﻿using System.Web;
using System.Web.Optimization;

namespace finalTrempProgect
{
    public class BundleConfig
    {
        // For more information on Bundling, visit http://go.microsoft.com/fwlink/?LinkId=254725
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryui").Include(
                        "~/Scripts/jquery-ui-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.unobtrusive*",
                        "~/Scripts/jquery.validate*"));
            bundles.Add(new ScriptBundle("~/bundles/angular").Include(
                       "~/Scripts/angular.js",
                       "~/Scripts/angular-route.js"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));
            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include("~/Content/themes/bootstrap/js/bootstrap.min.js",
                "~/Content/themes/bootstrap/js/bootstrap.js", "~/Content/themes/bootstrap/js/npm.js"));
            bundles.Add(new ScriptBundle("~/Content/themes/base/npm").Include("~/Content/themes/base/npm.js"));
            bundles.Add(new ScriptBundle("~/bundles/moment").Include("~/Content/themes/moment/min/locales.js",
                "~/Content/themes/moment/bootstrap-datetimepicker.css",
                 "~/Content/themes/moment/DTlocales/*.js",
                 "~/Content/themes/moment/bootstrap-datetimepicker.min.css",
                   "~/Content/themes/moment/bootstrap-datetimepicker.min.js",
                    "~/Content/themes/moment/bootstrap-datetimepicker.js",
                     "~/Content/themes/moment/locale/*.js",
                      "~/Content/themes/moment/templates/*.js",
                "~/Content/themes/moment/min/locales.min.js",
                "~/Content/themes/moment/min/moment-with-locales.js",
                "~/Content/themes/moment/min/moment-with-locales.min.js",
                "~/Content/themes/moment/min/moment.min.js",
                "~/Content/themes/moment/min/tests.js",
                 "~/Content/themes/moment/.bower.json",
                  "~/Content/themes/moment/bower.json",
                   "~/Content/themes/moment/CHANGELOG.md",
                    "~/Content/themes/moment/LICENSE.json",
                    "~/Content/themes/moment/moment.js"));
            bundles.Add(new StyleBundle("~/Content/css").Include("~/Content/site.css"));
            bundles.Add(new StyleBundle("~/bundles/bootstrapcss")
                .Include("~/Content/themes/bootstrap/css/bootstrap.min.css",
                "~/Content/themes/bootstrap/css/bootstrap-theme.css",
                "~/Content/themes/bootstrap/css/bootstrap-theme.css.map",
                "~/Content/themes/bootstrap/css/bootstrap-theme.min.css.map",
                "~/Content/themes/bootstrap/css/bootstrap-theme.min.css",
                "~/Content/themes/bootstrap/css/bootstrap.css",
                "~/Content/themes/bootstrap/css/bootstrap.css.map",
                "~/Content/themes/bootstrap/css/bootstrap.min.css",
                "~/Content/themes/bootstrap/css/bootstrap.min.css.map"));
            bundles.Add(new StyleBundle("~/bundles/bootstrapfont").Include(
                "~/Content/themes/bootstrap/fonts/glyphicons-halflings-regular.eot",
                "~/Content/themes/bootstrap/fonts/glyphicons-halflings-regular.svg",
                "~/Content/themes/bootstrap/fonts/glyphicons-halflings-regular.ttf",
                 "~/Content/themes/bootstrap/fonts/glyphicons-halflings-regular.woff",
                 "~/Content/themes/bootstrap/fonts/glyphicons-halflings-regular.woff2"));
            bundles.Add(new StyleBundle("~/bundles/style").Include("~/Content/themes/style/StyleSheetLayout.css", "~/Content/themes/style/style.css", "~/Content/themes/style/reset.css"));
            bundles.Add(new StyleBundle("~/Content/themes/base/css").Include(
                        "~/Content/themes/base/jquery.ui.core.css",
                        "~/Content/themes/base/jquery.ui.selectable.css",
                        "~/Content/themes/base/jquery.ui.accordion.css",
                        "~/Content/themes/base/jquery.ui.autocomplete.css",
                        "~/Content/themes/base/jquery.ui.button.css",
                        "~/Content/themes/base/jquery.ui.dialog.css",
                        "~/Content/themes/base/jquery.ui.slider.css",
                        "~/Content/themes/base/jquery.ui.tabs.css",
                        "~/Content/themes/base/jquery.ui.datepicker.css",
                        "~/Content/themes/base/jquery.ui.progressbar.css",
                        "~/Content/themes/base/jquery.ui.theme.css"));
            //BundleTable.EnableOptimizations = true;
        }
    }
}